VizH5P is a module in Drupal8 based on H5P to store, view and analyze user interaction data 
coming from xAPI and visualising it through plotly.js. IIT Bombay Eklavya Summer Internship Project.
